<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0">
        <span class="float-md-end d-none d-md-block">يعمل بواسطة فكرة سمارت <i data-feather="heart"></i>
        </span>
    </p>
</footer>
